"""Lambda that starts the GeoAI cutoff-based Step Functions pipeline on a schedule.

This replaces the old "create a single TransformJob" Lambda. It now triggers a Step Functions
state machine which runs:
  - Batch Transform for EARLY/MID/END cutoffs
  - Processing evaluation per cutoff
  - Processing comparison/report step

Environment variables (set by CloudFormation):
  STATE_MACHINE_ARN
  ARTIFACTS_BUCKET
  MODEL_NAME
  SAGEMAKER_ROLE_ARN
  TRANSFORM_INSTANCE_TYPE
  TRANSFORM_INSTANCE_COUNT
  EVAL_IMAGE_URI
  COMPARE_IMAGE_URI
  TARGET_COL
  CUTOFFS   (JSON list string, e.g. ["EARLY","MID","END"])
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone

import boto3

sfn = boto3.client("stepfunctions")


def handler(event, context):
    state_machine_arn = os.environ["STATE_MACHINE_ARN"]

    run_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    cutoffs = json.loads(os.environ.get("CUTOFFS", "["EARLY","MID","END"]"))

    payload = {
        "run_date": run_date,
        "bucket": os.environ["ARTIFACTS_BUCKET"],
        "model_name": os.environ["MODEL_NAME"],
        "transform_instance_type": os.environ.get("TRANSFORM_INSTANCE_TYPE", "ml.m5.large"),
        "transform_instance_count": int(os.environ.get("TRANSFORM_INSTANCE_COUNT", "1")),
        "eval_image_uri": os.environ["EVAL_IMAGE_URI"],
        "compare_image_uri": os.environ["COMPARE_IMAGE_URI"],
        "sagemaker_role_arn": os.environ["SAGEMAKER_ROLE_ARN"],
        "target_col": os.environ.get("TARGET_COL", "yield_bu_acre"),
        "cutoffs": cutoffs,
    }

    resp = sfn.start_execution(
        stateMachineArn=state_machine_arn,
        name=f"geoai-cutoff-{run_date.replace('-', '')}-{context.aws_request_id[:8]}",
        input=json.dumps(payload),
    )

    return {
        "message": "Started cutoff pipeline",
        "run_date": run_date,
        "executionArn": resp["executionArn"],
        "input": payload,
    }
